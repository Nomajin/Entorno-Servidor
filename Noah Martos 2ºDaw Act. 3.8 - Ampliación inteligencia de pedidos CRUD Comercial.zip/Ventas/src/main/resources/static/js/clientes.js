const searchInput = document.querySelector("#busqueda-clientes");
const searchForm = document.querySelector("#formulario-busqueda");
const clearButton = document.querySelector("#limpiar-busqueda");

if (searchInput && searchForm && clearButton) {
	const clientRows = [...document.querySelectorAll(".cliente-row")];
	const visibleCount = document.querySelector("#clientes-visibles");
	const noResultsRow = document.querySelector("#sin-resultados");

	const normalize = (value) => value
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, "")
		.toLocaleLowerCase();

	const filterClients = () => {
		const query = normalize(searchInput.value.trim());
		let visibleRows = 0;

		for (const row of clientRows) {
			const searchableText = [...row.querySelectorAll("td:not(:last-child)")]
				.map((cell) => cell.textContent)
				.join(" ");
			const matches = normalize(searchableText).includes(query);

			row.hidden = !matches;
			if (matches) visibleRows += 1;
		}

		visibleCount.textContent = visibleRows;
		noResultsRow.hidden = clientRows.length === 0 || visibleRows > 0;
	};

	searchForm.addEventListener("submit", (event) => {
		event.preventDefault();
		filterClients();
	});

	searchInput.addEventListener("search", filterClients);

	clearButton.addEventListener("click", () => {
		searchInput.value = "";
		filterClients();
		searchInput.focus();
	});
}