package org.iesvdm.dto;

public record PedidoEstadisticasDTO(
		double importeTotal,
		double importeMedio,
		double importeMaximo,
		double importeMinimo) {
}