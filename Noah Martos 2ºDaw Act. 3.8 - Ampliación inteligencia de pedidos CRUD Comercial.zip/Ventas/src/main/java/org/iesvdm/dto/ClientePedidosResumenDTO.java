package org.iesvdm.dto;

public record ClientePedidosResumenDTO(int clienteId, String nombreCliente, double importeTotal) {
}