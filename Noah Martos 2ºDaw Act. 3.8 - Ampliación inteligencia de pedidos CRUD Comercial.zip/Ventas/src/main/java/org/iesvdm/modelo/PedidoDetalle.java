package org.iesvdm.modelo;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PedidoDetalle {
	private int id;
	private double total;
	private LocalDate fecha;
	private int clienteId;
	private String clienteNombre;
	private String comercialNombre;
}