package org.iesvdm.modelo;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Pedido {
	private int id;
	private double total;
	private LocalDate fecha;
	private int idCliente;
	private int idComercial;
}