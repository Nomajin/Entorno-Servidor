package org.iesvdm.dao;

import java.util.List;

import org.iesvdm.dto.ClientePedidosResumenDTO;
import org.iesvdm.dto.PedidoEstadisticasDTO;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;

public interface PedidoDAO {
	List<Pedido> getByComercialId(int comercialId);
	PedidoEstadisticasDTO getEstadisticasByComercialId(int comercialId);
	List<ClientePedidosResumenDTO> findClientesConImportePedidosByComercialId(int comercialId);
	List<PedidoDetalle> findByComercialId(int comercialId);
	List<PedidoDetalle> findByClienteId(int clienteId);
}