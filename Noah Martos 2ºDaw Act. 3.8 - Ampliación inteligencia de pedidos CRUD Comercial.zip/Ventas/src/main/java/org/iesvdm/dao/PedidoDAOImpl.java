package org.iesvdm.dao;

import java.util.List;

import org.iesvdm.dto.ClientePedidosResumenDTO;
import org.iesvdm.dto.PedidoEstadisticasDTO;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class PedidoDAOImpl implements PedidoDAO {

	private static final String SELECT_PEDIDOS_CON_NOMBRES = """
			SELECT p.id, p.total, p.fecha, p.id_cliente,
				CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS nombre_cliente,
				CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS nombre_comercial
			FROM pedido p
			JOIN cliente c ON p.id_cliente = c.id
			JOIN comercial co ON p.id_comercial = co.id
			""";

	private static final RowMapper<PedidoDetalle> PEDIDO_DETALLE_ROW_MAPPER = (resultSet, rowNum) ->
			new PedidoDetalle(
					resultSet.getInt("id"),
					resultSet.getDouble("total"),
					resultSet.getObject("fecha", java.time.LocalDate.class),
					resultSet.getInt("id_cliente"),
					resultSet.getString("nombre_cliente"),
					resultSet.getString("nombre_comercial"));

	private final JdbcTemplate jdbcTemplate;

	public PedidoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<Pedido> getByComercialId(int comercialId) {
		return jdbcTemplate.query("""
				SELECT id, total, fecha, id_cliente, id_comercial
				FROM pedido
				WHERE id_comercial = ?
				ORDER BY fecha, id
				""", (resultSet, rowNum) -> new Pedido(
					resultSet.getInt("id"),
					resultSet.getDouble("total"),
					resultSet.getObject("fecha", java.time.LocalDate.class),
					resultSet.getInt("id_cliente"),
					resultSet.getInt("id_comercial")),
				comercialId);
	}

	@Override
	public PedidoEstadisticasDTO getEstadisticasByComercialId(int comercialId) {
		return jdbcTemplate.queryForObject("""
				SELECT COALESCE(SUM(total), 0) AS importe_total,
					COALESCE(AVG(total), 0) AS importe_medio,
					COALESCE(MAX(total), 0) AS importe_maximo,
					COALESCE(MIN(total), 0) AS importe_minimo
				FROM pedido
				WHERE id_comercial = ?
				""", (resultSet, rowNum) -> new PedidoEstadisticasDTO(
				resultSet.getDouble("importe_total"),
				resultSet.getDouble("importe_medio"),
				resultSet.getDouble("importe_maximo"),
				resultSet.getDouble("importe_minimo")),
				comercialId);
	}

	@Override
	public List<ClientePedidosResumenDTO> findClientesConImportePedidosByComercialId(int comercialId) {
		return jdbcTemplate.query("""
				SELECT c.id AS cliente_id,
					CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS nombre_cliente,
					SUM(p.total) AS importe_total
				FROM cliente c
				JOIN pedido p ON p.id_cliente = c.id
				WHERE EXISTS (
					SELECT 1
					FROM pedido pc
					WHERE pc.id_cliente = c.id AND pc.id_comercial = ?
				)
				GROUP BY c.id, c.nombre, c.apellido1, c.apellido2
				ORDER BY importe_total DESC, c.id
				""", (resultSet, rowNum) -> new ClientePedidosResumenDTO(
				resultSet.getInt("cliente_id"),
				resultSet.getString("nombre_cliente"),
				resultSet.getDouble("importe_total")),
				comercialId);
	}

	@Override
	public List<PedidoDetalle> findByComercialId(int comercialId) {
		return jdbcTemplate.query(
				SELECT_PEDIDOS_CON_NOMBRES + " WHERE p.id_comercial = ? ORDER BY p.fecha, p.id",
				PEDIDO_DETALLE_ROW_MAPPER,
				comercialId);
	}

	@Override
	public List<PedidoDetalle> findByClienteId(int clienteId) {
		return jdbcTemplate.query(
				SELECT_PEDIDOS_CON_NOMBRES + " WHERE p.id_cliente = ? ORDER BY p.fecha, p.id",
				PEDIDO_DETALLE_ROW_MAPPER,
				clienteId);
	}
}