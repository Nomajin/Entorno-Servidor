package org.iesvdm.controlador;

import org.springframework.stereotype.Controller;
import org.iesvdm.servicios.ClienteService;
import org.springframework.ui.Model;
import java.util.List;
import org.iesvdm.modelo.Cliente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;


@Controller
public class ClienteControlador {

    private final ClienteService clienteService;

    public ClienteControlador(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listar(Model model) {

        List<Cliente> listaClientes = clienteService.listAll();
        model.addAttribute("listaClientes", listaClientes);

        return "clientes";
    }

    @GetMapping("/clientes/crear")
    public String formularioCrear() {
        return "formulario-cliente";
    }

    @PostMapping("/clientes/crear")
    public String crear(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String apellido1,
            @RequestParam(required = false) String apellido2,
            @RequestParam(required = false) String ciudad,
            @RequestParam(required = false) Integer categoria,
            Model model) {
        if (nombre == null || nombre.isBlank() || apellido1 == null || apellido1.isBlank()) {
            model.addAttribute("error", "El nombre y el primer apellido son obligatorios.");
            model.addAttribute("nombre", nombre);
            model.addAttribute("apellido1", apellido1);
            model.addAttribute("apellido2", apellido2);
            model.addAttribute("ciudad", ciudad);
            model.addAttribute("categoria", categoria);
            return "formulario-cliente";
        }

        Cliente cliente = new Cliente(
                0,
                nombre.trim(),
                apellido1.trim(),
                apellido2 == null || apellido2.isBlank() ? null : apellido2.trim(),
                ciudad == null || ciudad.isBlank() ? null : ciudad.trim(),
                categoria);
        clienteService.create(cliente);
        return "redirect:/clientes";
    }

    @GetMapping("/clientes/{id}")
    public String detalle(@PathVariable int id, Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        model.addAttribute("cliente", cliente);
        model.addAttribute("pedidos", clienteService.listPedidosByCliente(id));
        return "detalle-cliente";
    }
    
}
