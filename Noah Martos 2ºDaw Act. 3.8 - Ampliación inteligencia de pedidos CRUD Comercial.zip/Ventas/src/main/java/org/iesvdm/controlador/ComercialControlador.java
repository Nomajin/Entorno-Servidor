package org.iesvdm.controlador;

import org.iesvdm.modelo.Comercial;
import org.iesvdm.servicios.ComercialService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

@Controller
public class ComercialControlador {

	private final ComercialService comercialService;

	public ComercialControlador(ComercialService comercialService) {
		this.comercialService = comercialService;
	}

	@GetMapping("/comerciales/{id}")
	public String detalle(@PathVariable int id, Model model) {
		Comercial comercial = comercialService.find(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

		model.addAttribute("comercial", comercial);
		model.addAttribute("pedidos", comercialService.listPedidosByComercial(id));
		model.addAttribute("estadisticas", comercialService.getEstadisticasPedidosByComercial(id));
		model.addAttribute("clientesPorImportePedidos", comercialService.listClientesPorImportePedidos(id));
		return "detalle-comercial";
	}
}