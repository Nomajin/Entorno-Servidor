package org.iesvdm.controlador;

import org.springframework.stereotype.Controller;
import org.iesvdm.servicios.ClienteService;
import org.springframework.ui.Model;
import java.util.List;
import org.iesvdm.modelo.Cliente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;


@Controller
public class ClienteControlador {

    private final ClienteService clienteService;

    public ClienteControlador(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listar(Model model) {

        List<Cliente> listaClientes = clienteService.listAll();
        model.addAttribute("listaClientes", listaClientes);

        return "clientes";
    }

    @GetMapping("/clientes/{id}")
    public String detalle(@PathVariable int id, Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        model.addAttribute("cliente", cliente);
        model.addAttribute("pedidos", clienteService.listPedidosByCliente(id));
        return "detalle-cliente";
    }
    
}
