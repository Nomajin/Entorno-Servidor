package org.iesvdm.servicios;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import org.iesvdm.dao.ClienteDAO;
import org.iesvdm.dao.PedidoDAO;
import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.PedidoDetalle;


@Service
public class ClienteService {

    private final ClienteDAO clienteDao;
    private final PedidoDAO pedidoDAO;

    public ClienteService(ClienteDAO clienteDao, PedidoDAO pedidoDAO) {
        this.clienteDao = clienteDao;
        this.pedidoDAO = pedidoDAO;
    }

    public List<Cliente> listAll() {
        return clienteDao.getAll();
    }

    public Optional<Cliente> find(int id) {
        return clienteDao.find(id);
    }

    public List<PedidoDetalle> listPedidosByCliente(int clienteId) {
        return pedidoDAO.findByClienteId(clienteId);
    }
    
}
