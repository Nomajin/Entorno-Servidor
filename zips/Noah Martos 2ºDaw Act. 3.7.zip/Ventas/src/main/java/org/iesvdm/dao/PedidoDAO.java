package org.iesvdm.dao;

import java.util.List;

import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;

public interface PedidoDAO {
	List<Pedido> getByComercialId(int comercialId);
	List<PedidoDetalle> findByComercialId(int comercialId);
	List<PedidoDetalle> findByClienteId(int clienteId);
}