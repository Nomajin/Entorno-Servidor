package org.iesvdm.dao;

import java.util.List;

import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class PedidoDAOImpl implements PedidoDAO {

	private static final String SELECT_PEDIDOS_CON_NOMBRES = """
			SELECT p.id, p.total, p.fecha, p.id_cliente,
				CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS nombre_cliente,
				CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS nombre_comercial
			FROM pedido p
			JOIN cliente c ON p.id_cliente = c.id
			JOIN comercial co ON p.id_comercial = co.id
			""";

	private static final RowMapper<PedidoDetalle> PEDIDO_DETALLE_ROW_MAPPER = (resultSet, rowNum) ->
			new PedidoDetalle(
					resultSet.getInt("id"),
					resultSet.getDouble("total"),
					resultSet.getObject("fecha", java.time.LocalDate.class),
					resultSet.getInt("id_cliente"),
					resultSet.getString("nombre_cliente"),
					resultSet.getString("nombre_comercial"));

	private final JdbcTemplate jdbcTemplate;

	public PedidoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<Pedido> getByComercialId(int comercialId) {
		return jdbcTemplate.query("""
				SELECT id, total, fecha, id_cliente, id_comercial
				FROM pedido
				WHERE id_comercial = ?
				ORDER BY fecha, id
				""", (resultSet, rowNum) -> new Pedido(
					resultSet.getInt("id"),
					resultSet.getDouble("total"),
					resultSet.getObject("fecha", java.time.LocalDate.class),
					resultSet.getInt("id_cliente"),
					resultSet.getInt("id_comercial")),
				comercialId);
	}

	@Override
	public List<PedidoDetalle> findByComercialId(int comercialId) {
		return jdbcTemplate.query(
				SELECT_PEDIDOS_CON_NOMBRES + " WHERE p.id_comercial = ? ORDER BY p.fecha, p.id",
				PEDIDO_DETALLE_ROW_MAPPER,
				comercialId);
	}

	@Override
	public List<PedidoDetalle> findByClienteId(int clienteId) {
		return jdbcTemplate.query(
				SELECT_PEDIDOS_CON_NOMBRES + " WHERE p.id_cliente = ? ORDER BY p.fecha, p.id",
				PEDIDO_DETALLE_ROW_MAPPER,
				clienteId);
	}
}