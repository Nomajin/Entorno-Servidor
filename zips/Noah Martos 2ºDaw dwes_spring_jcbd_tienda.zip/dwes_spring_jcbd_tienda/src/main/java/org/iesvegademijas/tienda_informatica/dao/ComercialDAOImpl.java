package org.iesvegademijas.tienda_informatica.dao;

import java.util.List;
import java.util.Optional;

import org.iesvegademijas.tienda_informatica.modelo.Comercial;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ComercialDAOImpl implements ComercialDAO {

	private static final String SELECT_COLUMNS = "SELECT id, nombre, apellido1, apellido2, `comisión` AS comision FROM comercial";
	private final JdbcTemplate jdbcTemplate;

	public ComercialDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private Comercial mapComercial(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
		return new Comercial(rs.getInt("id"), rs.getString("nombre"), rs.getString("apellido1"),
				rs.getString("apellido2"), (Float) rs.getObject("comision"));
	}

	@Override
	public void create(Comercial comercial) {
		jdbcTemplate.update("INSERT INTO comercial (nombre, apellido1, apellido2, `comisión`) VALUES (?, ?, ?, ?)",
				comercial.getNombre(), comercial.getApellido1(), comercial.getApellido2(), comercial.getComision());
	}

	@Override
	public List<Comercial> getAll() {
		return jdbcTemplate.query(SELECT_COLUMNS, this::mapComercial);
	}

	@Override
	public Optional<Comercial> find(int id) {
		return jdbcTemplate.query(SELECT_COLUMNS + " WHERE id = ?", this::mapComercial, id).stream().findFirst();
	}

	@Override
	public void update(Comercial comercial) {
		jdbcTemplate.update("UPDATE comercial SET nombre = ?, apellido1 = ?, apellido2 = ?, `comisión` = ? WHERE id = ?",
				comercial.getNombre(), comercial.getApellido1(), comercial.getApellido2(), comercial.getComision(), comercial.getId());
	}

	@Override
	public void delete(int id) {
		jdbcTemplate.update("DELETE FROM comercial WHERE id = ?", id);
	}
}