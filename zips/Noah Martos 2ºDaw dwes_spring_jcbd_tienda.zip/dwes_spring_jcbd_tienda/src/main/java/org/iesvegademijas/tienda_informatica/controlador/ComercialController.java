package org.iesvegademijas.tienda_informatica.controlador;

import org.iesvegademijas.tienda_informatica.modelo.Comercial;
import org.iesvegademijas.tienda_informatica.servicio.ComercialService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ComercialController {

	private final ComercialService comercialService;

	public ComercialController(ComercialService comercialService) {
		this.comercialService = comercialService;
	}

	@GetMapping("/comerciales")
	public String listar(Model model) {
		model.addAttribute("listaComerciales", comercialService.listAll());
		return "comerciales";
	}

	@GetMapping("/comerciales/{id}")
	public String detalle(@PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
		Comercial comercial = comercialService.one(id);
		if (comercial == null) {
			redirectAttributes.addFlashAttribute("error", "El comercial solicitado no existe.");
			return "redirect:/comerciales";
		}
		model.addAttribute("comercial", comercial);
		return "detalle-comercial";
	}

	@GetMapping("/comerciales/crear")
	public String crear(Model model) {
		model.addAttribute("comercial", new Comercial());
		model.addAttribute("tituloFormulario", "Crear comercial");
		model.addAttribute("formAction", "/comerciales/crear");
		return "formulario-comercial";
	}

	@PostMapping("/comerciales/crear")
	public String submitCrear(@ModelAttribute Comercial comercial) {
		comercialService.newComercial(comercial);
		return "redirect:/comerciales";
	}

	@GetMapping("/comerciales/editar/{id}")
	public String editar(@PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
		Comercial comercial = comercialService.one(id);
		if (comercial == null) {
			redirectAttributes.addFlashAttribute("error", "El comercial solicitado no existe.");
			return "redirect:/comerciales";
		}
		model.addAttribute("comercial", comercial);
		model.addAttribute("tituloFormulario", "Editar comercial");
		model.addAttribute("formAction", "/comerciales/editar/" + id);
		return "formulario-comercial";
	}

	@PostMapping("/comerciales/editar/{id}")
	public String submitEditar(@PathVariable int id, @ModelAttribute Comercial comercial) {
		comercial.setId(id);
		comercialService.replaceComercial(comercial);
		return "redirect:/comerciales";
	}

	@PostMapping("/comerciales/borrar/{id}")
	public String submitBorrar(@PathVariable int id, RedirectAttributes redirectAttributes) {
		try {
			comercialService.deleteComercial(id);
		} catch (DataIntegrityViolationException exception) {
			redirectAttributes.addFlashAttribute("error", "No se puede eliminar el comercial porque tiene pedidos asociados.");
		}
		return "redirect:/comerciales";
	}
}