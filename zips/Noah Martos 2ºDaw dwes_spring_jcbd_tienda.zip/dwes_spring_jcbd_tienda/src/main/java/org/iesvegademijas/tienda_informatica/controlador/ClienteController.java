package org.iesvegademijas.tienda_informatica.controlador;

import org.iesvegademijas.tienda_informatica.modelo.Cliente;
import org.iesvegademijas.tienda_informatica.servicio.ClienteService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ClienteController {

	private final ClienteService clienteService;

	public ClienteController(ClienteService clienteService) {
		this.clienteService = clienteService;
	}

	@GetMapping("/clientes")
	public String listar(Model model) {
		model.addAttribute("listaClientes", clienteService.listAll());
		return "clientes";
	}

	@GetMapping("/clientes/{id}")
	public String detalle(@PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
		Cliente cliente = clienteService.one(id);
		if (cliente == null) {
			redirectAttributes.addFlashAttribute("error", "El cliente solicitado no existe.");
			return "redirect:/clientes";
		}
		model.addAttribute("cliente", cliente);
		return "detalle-cliente";
	}

	@GetMapping("/clientes/crear")
	public String crear(Model model) {
		model.addAttribute("cliente", new Cliente());
		model.addAttribute("tituloFormulario", "Crear cliente");
		model.addAttribute("formAction", "/clientes/crear");
		return "formulario-cliente";
	}

	@PostMapping("/clientes/crear")
	public String submitCrear(@ModelAttribute Cliente cliente) {
		clienteService.newCliente(cliente);
		return "redirect:/clientes";
	}

	@GetMapping("/clientes/editar/{id}")
	public String editar(@PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
		Cliente cliente = clienteService.one(id);
		if (cliente == null) {
			redirectAttributes.addFlashAttribute("error", "El cliente solicitado no existe.");
			return "redirect:/clientes";
		}
		model.addAttribute("cliente", cliente);
		model.addAttribute("tituloFormulario", "Editar cliente");
		model.addAttribute("formAction", "/clientes/editar/" + id);
		return "formulario-cliente";
	}

	@PostMapping("/clientes/editar/{id}")
	public String submitEditar(@PathVariable int id, @ModelAttribute Cliente cliente) {
		cliente.setId(id);
		clienteService.replaceCliente(cliente);
		return "redirect:/clientes";
	}

	@PostMapping("/clientes/borrar/{id}")
	public String submitBorrar(@PathVariable int id, RedirectAttributes redirectAttributes) {
		try {
			clienteService.deleteCliente(id);
		} catch (DataIntegrityViolationException exception) {
			redirectAttributes.addFlashAttribute("error", "No se puede eliminar el cliente porque tiene pedidos asociados.");
		}
		return "redirect:/clientes";
	}
}