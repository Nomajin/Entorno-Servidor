package org.iesvegademijas.tienda_informatica;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.List;

import org.iesvegademijas.tienda_informatica.controlador.ClienteController;
import org.iesvegademijas.tienda_informatica.controlador.ComercialController;
import org.iesvegademijas.tienda_informatica.modelo.Cliente;
import org.iesvegademijas.tienda_informatica.modelo.Comercial;
import org.iesvegademijas.tienda_informatica.servicio.ClienteService;
import org.iesvegademijas.tienda_informatica.servicio.ComercialService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(controllers = { ClienteController.class, ComercialController.class })
class ClienteComercialControllerTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ClienteService clienteService;

	@MockBean
	private ComercialService comercialService;

	@Test
	void listaClientesRenderizaGridYDatos() throws Exception {
		when(clienteService.listAll()).thenReturn(List.of(new Cliente(1, "Aarón", "Rivero", "Gómez", "Almería", 100)));

		mockMvc.perform(get("/clientes"))
				.andExpect(status().isOk())
				.andExpect(view().name("clientes"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("col-lg-1")))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Aarón")));
	}

	@Test
	void listaComercialesRenderizaGridYDatos() throws Exception {
		when(comercialService.listAll()).thenReturn(List.of(new Comercial(1, "Daniel", "Sáez", "Vega", 0.15f)));

		mockMvc.perform(get("/comerciales"))
				.andExpect(status().isOk())
				.andExpect(view().name("comerciales"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("col-md-1")))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Daniel")));
	}

	@Test
	void formularioClienteRenderizaParaCrear() throws Exception {
		mockMvc.perform(get("/clientes/crear"))
				.andExpect(status().isOk())
				.andExpect(view().name("formulario-cliente"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Crear cliente")));
	}

	@Test
	void formularioComercialRenderizaParaCrear() throws Exception {
		mockMvc.perform(get("/comerciales/crear"))
				.andExpect(status().isOk())
				.andExpect(view().name("formulario-comercial"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Crear comercial")));
	}
}