package org.iesvdm.dto;

import java.time.LocalDate;

public record ComercialAsignadoDTO(int comercialId, String nombreComercial, LocalDate fecha, int prioridad) {
}
