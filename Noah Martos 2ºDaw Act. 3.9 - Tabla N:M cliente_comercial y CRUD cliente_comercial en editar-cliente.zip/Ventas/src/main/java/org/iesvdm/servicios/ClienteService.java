package org.iesvdm.servicios;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import org.iesvdm.dao.ClienteDAO;
import org.iesvdm.dao.PedidoDAO;
import org.iesvdm.dto.ComercialAsignadoDTO;
import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.modelo.PedidoDetalle;
import java.time.LocalDate;


@Service
public class ClienteService {

    private final ClienteDAO clienteDao;
    private final PedidoDAO pedidoDAO;

    public ClienteService(ClienteDAO clienteDao, PedidoDAO pedidoDAO) {
        this.clienteDao = clienteDao;
        this.pedidoDAO = pedidoDAO;
    }

    public List<Cliente> listAll() {
        return clienteDao.getAll();
    }

    public void create(Cliente cliente) {
        clienteDao.create(cliente);
    }

    public Optional<Cliente> find(int id) {
        return clienteDao.find(id);
    }

    public void update(Cliente cliente) {
        clienteDao.update(cliente);
    }

    public List<Comercial> listComercialesDisponibles(int clienteId) {
        return clienteDao.getComercialesDisponibles(clienteId);
    }

    public List<ComercialAsignadoDTO> listComercialesAsignados(int clienteId) {
        return clienteDao.getComercialesAsignados(clienteId);
    }

    public boolean addComercial(int clienteId, int comercialId, LocalDate fecha, int prioridad) {
        return clienteDao.addComercial(clienteId, comercialId, fecha, prioridad);
    }

    public boolean removeComercial(int clienteId, int comercialId) {
        return clienteDao.removeComercial(clienteId, comercialId);
    }

    public List<PedidoDetalle> listPedidosByCliente(int clienteId) {
        return pedidoDAO.findByClienteId(clienteId);
    }
    
}
