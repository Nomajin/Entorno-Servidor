package org.iesvdm.controlador;

import org.springframework.stereotype.Controller;
import org.iesvdm.servicios.ClienteService;
import org.springframework.ui.Model;
import java.util.List;
import org.iesvdm.modelo.Cliente;
import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;


@Controller
public class ClienteControlador {

    private final ClienteService clienteService;

    public ClienteControlador(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listar(Model model) {

        List<Cliente> listaClientes = clienteService.listAll();
        model.addAttribute("listaClientes", listaClientes);

        return "clientes";
    }

    @GetMapping("/clientes/crear")
    public String formularioCrear() {
        return "formulario-cliente";
    }

    @PostMapping("/clientes/crear")
    public String crear(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String apellido1,
            @RequestParam(required = false) String apellido2,
            @RequestParam(required = false) String ciudad,
            @RequestParam(required = false) Integer categoria,
            Model model) {
        if (nombre == null || nombre.isBlank() || apellido1 == null || apellido1.isBlank()) {
            model.addAttribute("error", "El nombre y el primer apellido son obligatorios.");
            model.addAttribute("nombre", nombre);
            model.addAttribute("apellido1", apellido1);
            model.addAttribute("apellido2", apellido2);
            model.addAttribute("ciudad", ciudad);
            model.addAttribute("categoria", categoria);
            return "formulario-cliente";
        }

        Cliente cliente = new Cliente(
                0,
                nombre.trim(),
                apellido1.trim(),
                apellido2 == null || apellido2.isBlank() ? null : apellido2.trim(),
                ciudad == null || ciudad.isBlank() ? null : ciudad.trim(),
                categoria);
        clienteService.create(cliente);
        return "redirect:/clientes";
    }

    @GetMapping("/clientes/editar/{id}")
    public String formularioEditar(@PathVariable int id, Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        return mostrarFormularioEdicion(cliente, model);
    }

    @PostMapping("/clientes/editar/{id}")
    public String actualizar(
            @PathVariable int id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String apellido1,
            @RequestParam(required = false) String apellido2,
            @RequestParam(required = false) String ciudad,
            @RequestParam(required = false) Integer categoria,
            Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        cliente.setNombre(nombre == null ? "" : nombre.trim());
        cliente.setApellido1(apellido1 == null ? "" : apellido1.trim());
        cliente.setApellido2(apellido2 == null || apellido2.isBlank() ? null : apellido2.trim());
        cliente.setCiudad(ciudad == null || ciudad.isBlank() ? null : ciudad.trim());
        cliente.setCategoria(categoria);

        if (cliente.getNombre().isBlank() || cliente.getApellido1().isBlank()) {
            model.addAttribute("error", "El nombre y el primer apellido son obligatorios.");
            return mostrarFormularioEdicion(cliente, model);
        }

        clienteService.update(cliente);
        return "redirect:/clientes";
    }

    @PostMapping("/clientes/editar/{id}/comerciales")
    public String anadirComercial(
            @PathVariable int id,
            @RequestParam(required = false) Integer comercialId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            @RequestParam(required = false) Integer prioridad,
            Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        if (comercialId == null || fecha == null || prioridad == null || prioridad < 1) {
            model.addAttribute("asignacionError", "Selecciona un comercial, una fecha y una prioridad válida.");
            return mostrarFormularioEdicion(cliente, model);
        }

        if (!clienteService.addComercial(id, comercialId, fecha, prioridad)) {
            model.addAttribute("asignacionError", "El comercial ya está asignado o no existe.");
            return mostrarFormularioEdicion(cliente, model);
        }

        return "redirect:/clientes/editar/" + id;
    }

    @PostMapping("/clientes/editar/{id}/comerciales/{comercialId}/borrar")
    public String borrarVinculoComercial(
            @PathVariable int id,
            @PathVariable int comercialId) {
        clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        clienteService.removeComercial(id, comercialId);
        return "redirect:/clientes/editar/" + id;
    }

    @GetMapping("/clientes/{id}")
    public String detalle(@PathVariable int id, Model model) {
        Cliente cliente = clienteService.find(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        model.addAttribute("cliente", cliente);
        model.addAttribute("pedidos", clienteService.listPedidosByCliente(id));
        return "detalle-cliente";
    }

    private String mostrarFormularioEdicion(Cliente cliente, Model model) {
        model.addAttribute("cliente", cliente);
        model.addAttribute("comercialesDisponibles", clienteService.listComercialesDisponibles(cliente.getId()));
        model.addAttribute("comercialesAsignados", clienteService.listComercialesAsignados(cliente.getId()));
        return "formulario-cliente";
    }
    
}
