package org.iesvdm.dao;

import java.util.List;
import java.util.Optional;
import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.dto.ComercialAsignadoDTO;
import java.time.LocalDate;

public interface ClienteDAO {
	public void create(Cliente cliente);
	public List<Cliente> getAll();
	public Optional<Cliente>  find(int id);
	public void update(Cliente cliente);
	public void delete(int id);
	public List<Comercial> getComercialesDisponibles(int clienteId);
	public List<ComercialAsignadoDTO> getComercialesAsignados(int clienteId);
	public boolean addComercial(int clienteId, int comercialId, LocalDate fecha, int prioridad);
	public boolean removeComercial(int clienteId, int comercialId);
}