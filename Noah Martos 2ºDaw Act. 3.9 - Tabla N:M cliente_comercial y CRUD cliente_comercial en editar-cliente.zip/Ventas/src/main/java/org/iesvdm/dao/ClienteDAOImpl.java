package org.iesvdm.dao;

import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.dto.ComercialAsignadoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

//Anotación lombok para logging (traza) de la aplicación
@Slf4j

//Un Repository es un componente y a su vez un estereotipo de Spring 
//que forma parte de la 'capa de persistencia'.
@Repository
public class ClienteDAOImpl implements ClienteDAO {

	 //Plantilla jdbc inyectada automáticamente por el framework Spring, gracias a la anotación @Autowired.
	 private final JdbcTemplate jdbcTemplate;

	ClienteDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/**
	 * Inserta en base de datos el nuevo Cliente, actualizando el id en el bean Cliente.
	 */
	@Override	
	public synchronized void create(Cliente cliente) {
		
							//Desde java15+ se tiene la triple quote """ para bloques de texto como cadenas.
		String sqlInsert = """
							INSERT INTO cliente (nombre, apellido1, apellido2, ciudad, categoría) 
							VALUES  (     ?,         ?,         ?,       ?,         ?)
						   """;
		
		
		//Sin recuperación de id generado
//		int rows = jdbcTemplate.update(sqlInsert,
//							cliente.getNombre(),
//							cliente.getApellido1(),
//							cliente.getApellido2(),
//							cliente.getCiudad(),
//							cliente.getCategoria()
//					);

		//Con recuperación de id generado
            KeyHolder keyHolder = new GeneratedKeyHolder();
		int rows = jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(sqlInsert, new String[] { "id" });
			int idx = 1;
			ps.setString(idx++, cliente.getNombre());
			ps.setString(idx++, cliente.getApellido1());
			ps.setString(idx++, cliente.getApellido2());
			ps.setString(idx++, cliente.getCiudad());
			ps.setObject(idx, cliente.getCategoria());
			return ps;
		},keyHolder);
		
		cliente.setId(keyHolder.getKey().intValue());

		log.info("Insertados {} registros.", rows);
	}

	/**
	 * Devuelve lista con todos los Clientes.
	 */
	@Override
	public List<Cliente> getAll() {
		
		List<Cliente> listFab = jdbcTemplate.query(
                "SELECT * FROM cliente",
                (rs, rowNum) -> new Cliente(rs.getInt("id"),
                						 	rs.getString("nombre"),
                						 	rs.getString("apellido1"),
                						 	rs.getString("apellido2"),
                						 	rs.getString("ciudad"),
						 						rs.getObject("categoría", Integer.class)
                						 	)
        );

		log.info("Devueltos {} registros.", listFab.size());
		
        return listFab;
        
	}

	/**
	 * Devuelve Optional de Cliente con el ID dado.
	 */
	@Override
	public Optional<Cliente> find(int id) {
		
		Cliente fab =  jdbcTemplate
				.queryForObject("SELECT * FROM cliente WHERE id = ?"														
								, (rs, rowNum) -> new Cliente(rs.getInt("id"),
            						 						rs.getString("nombre"),
            						 						rs.getString("apellido1"),
            						 						rs.getString("apellido2"),
            						 						rs.getString("ciudad"),
									 						rs.getObject("categoría", Integer.class))
								, id);
		
		if (fab != null) { 
			return Optional.of(fab);}
		else { 
			log.info("Cliente no encontrado.");
		return Optional.empty(); }
        
	}
	/**
	 * Actualiza Cliente con campos del bean Cliente según ID del mismo.
	 */
	@Override
	public void update(Cliente cliente) {
		
		int rows = jdbcTemplate.update("""
										UPDATE cliente SET 
														nombre = ?, 
														apellido1 = ?, 
														apellido2 = ?,
														ciudad = ?,
														categoría = ?  
												WHERE id = ?
										""", cliente.getNombre()
										, cliente.getApellido1()
										, cliente.getApellido2()
										, cliente.getCiudad()
										, cliente.getCategoria()
										, cliente.getId());
		
		log.info("Update de Cliente con {} registros actualizados.", rows);
    
	}

	/**
	 * Borra Cliente con ID proporcionado.
	 */
	@Override
	public void delete(int id) {
		
		int rows = jdbcTemplate.update("DELETE FROM cliente WHERE id = ?", id);
		
		log.info("Delete de Cliente con {} registros eliminados.", rows);		
	}

	@Override
	public List<Comercial> getComercialesDisponibles(int clienteId) {
		return jdbcTemplate.query("""
				SELECT c.id, c.nombre, c.apellido1, c.apellido2, c.`comisión`
				FROM comercial c
				WHERE NOT EXISTS (
					SELECT 1 FROM cliente_has_comercial cc
					WHERE cc.cliente_id = ? AND cc.comercial_id = c.id
				)
				ORDER BY c.apellido1, c.nombre, c.id
				""", (rs, rowNum) -> new Comercial(
					rs.getInt("id"),
					rs.getString("nombre"),
					rs.getString("apellido1"),
					rs.getString("apellido2"),
					rs.getObject("comisión", Float.class)),
				clienteId);
	}

	@Override
	public List<ComercialAsignadoDTO> getComercialesAsignados(int clienteId) {
		return jdbcTemplate.query("""
				SELECT c.id AS comercial_id,
					CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS nombre_comercial,
					cc.fecha, cc.prioridad
				FROM cliente_has_comercial cc
				JOIN comercial c ON c.id = cc.comercial_id
				WHERE cc.cliente_id = ?
				ORDER BY cc.prioridad, cc.fecha, c.apellido1, c.nombre
				""", (rs, rowNum) -> new ComercialAsignadoDTO(
					rs.getInt("comercial_id"),
					rs.getString("nombre_comercial"),
					rs.getObject("fecha", LocalDate.class),
					rs.getInt("prioridad")),
				clienteId);
	}

	@Override
	public boolean addComercial(int clienteId, int comercialId, LocalDate fecha, int prioridad) {
		int rows = jdbcTemplate.update("""
				INSERT INTO cliente_has_comercial (cliente_id, comercial_id, fecha, prioridad)
				SELECT ?, c.id, ?, ?
				FROM comercial c
				WHERE c.id = ?
				AND NOT EXISTS (
					SELECT 1 FROM cliente_has_comercial cc
					WHERE cc.cliente_id = ? AND cc.comercial_id = c.id
				)
				""", clienteId, fecha, prioridad, comercialId, clienteId);
		return rows == 1;
	}

	@Override
	public boolean removeComercial(int clienteId, int comercialId) {
		int rows = jdbcTemplate.update("""
				DELETE FROM cliente_has_comercial
				WHERE cliente_id = ? AND comercial_id = ?
				""", clienteId, comercialId);
		return rows == 1;
	}
	
}

		
