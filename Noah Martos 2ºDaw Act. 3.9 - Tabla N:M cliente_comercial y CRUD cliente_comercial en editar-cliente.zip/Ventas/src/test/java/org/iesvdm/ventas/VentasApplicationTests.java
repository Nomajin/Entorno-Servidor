package org.iesvdm.ventas;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.iesvdm.dao.ComercialDAO;
import org.iesvdm.dto.ComercialAsignadoDTO;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.servicios.ClienteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
class VentasApplicationTests {

	@Autowired
	private ClienteService clienteService;

	@Autowired
	private ComercialDAO comercialDAO;

	@Autowired
	private WebApplicationContext applicationContext;

	private MockMvc mockMvc;

	@BeforeEach
	void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
	}

	@Test
	void contextLoads() {
	}

	@Test
	@Transactional
	void listaComercialVinculadoConFechaYPrioridad() {
		Comercial comercial = new Comercial(0, "Comercial de prueba", "Temporal", null, 0.1f);
		comercialDAO.create(comercial);

		LocalDate fecha = LocalDate.of(2026, 11, 13);
		assertTrue(clienteService.addComercial(1, comercial.getId(), fecha, 2));
		ComercialAsignadoDTO asignacion = new ComercialAsignadoDTO(
				comercial.getId(), "Comercial de prueba Temporal", fecha, 2);
		assertTrue(clienteService.listComercialesAsignados(1).contains(asignacion));

		try {
			mockMvc.perform(get("/clientes/editar/1"))
					.andExpect(status().isOk())
					.andExpect(content().string(containsString("Borrar")))
					.andExpect(content().string(containsString(
							"/clientes/editar/1/comerciales/" + comercial.getId() + "/borrar")));

			mockMvc.perform(post("/clientes/editar/1/comerciales/{comercialId}/borrar", comercial.getId()))
					.andExpect(status().is3xxRedirection())
					.andExpect(redirectedUrl("/clientes/editar/1"));
		} catch (Exception exception) {
			throw new AssertionError(exception);
		}

		assertFalse(clienteService.listComercialesAsignados(1).contains(asignacion));
		assertTrue(comercialDAO.find(comercial.getId()).isPresent());
	}

}
