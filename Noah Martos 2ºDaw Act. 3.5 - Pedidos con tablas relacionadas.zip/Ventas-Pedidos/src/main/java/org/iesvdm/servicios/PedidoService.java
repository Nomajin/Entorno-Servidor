package org.iesvdm.servicios;

import java.util.List;
import java.util.Optional;

import org.iesvdm.dao.PedidoDAO;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.stereotype.Service;

@Service
public class PedidoService {

	private final PedidoDAO pedidoDao;

	public PedidoService(PedidoDAO pedidoDao) {
		this.pedidoDao = pedidoDao;
	}

	public void create(Pedido pedido) {
		pedidoDao.create(pedido);
	}

	public List<Pedido> listAll() {
		return pedidoDao.getAll();
	}

	public Optional<Pedido> find(int id) {
		return pedidoDao.find(id);
	}

	public List<PedidoDetalle> listAllDetalles() {
		return pedidoDao.getAllDetalles();
	}

	public Optional<PedidoDetalle> findDetalle(int id) {
		return pedidoDao.findDetalle(id);
	}

	public void update(Pedido pedido) {
		pedidoDao.update(pedido);
	}

	public void delete(int id) {
		pedidoDao.delete(id);
	}
}