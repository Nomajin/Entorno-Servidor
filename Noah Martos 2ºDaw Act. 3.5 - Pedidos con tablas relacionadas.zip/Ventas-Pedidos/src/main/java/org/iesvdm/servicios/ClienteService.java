package org.iesvdm.servicios;

import org.springframework.stereotype.Service;
import java.util.List;
import org.iesvdm.dao.ClienteDAO;
import org.iesvdm.modelo.Cliente;


@Service
public class ClienteService {

    private final ClienteDAO clienteDao;

    public ClienteService(ClienteDAO clienteDao) {
        this.clienteDao = clienteDao;
    }

    public List<Cliente> listAll() {
        return clienteDao.getAll();
    }

    public void delete(int id) {
        clienteDao.delete(id);
    }
    
}
