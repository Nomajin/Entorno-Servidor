package org.iesvdm.servicios;

import java.util.List;

import org.iesvdm.dao.ComercialDAO;
import org.iesvdm.modelo.Comercial;
import org.springframework.stereotype.Service;

@Service
public class ComercialService {

	private final ComercialDAO comercialDao;

	public ComercialService(ComercialDAO comercialDao) {
		this.comercialDao = comercialDao;
	}

	public List<Comercial> listAll() {
		return comercialDao.getAll();
	}

	public void delete(int id) {
		comercialDao.delete(id);
	}
}