package org.iesvdm.controlador;

import org.iesvdm.servicios.ComercialService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ComercialControlador {

	private final ComercialService comercialService;

	public ComercialControlador(ComercialService comercialService) {
		this.comercialService = comercialService;
	}

	@PostMapping("/comerciales/borrar/{id}")
	public String borrar(@PathVariable int id) {
		comercialService.delete(id);
		return "redirect:/pedidos";
	}
}