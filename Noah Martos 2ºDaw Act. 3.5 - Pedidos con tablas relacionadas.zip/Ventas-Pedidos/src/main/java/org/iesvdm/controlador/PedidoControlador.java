package org.iesvdm.controlador;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.iesvdm.servicios.ClienteService;
import org.iesvdm.servicios.ComercialService;
import org.iesvdm.servicios.PedidoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

@Controller
public class PedidoControlador {

	private final PedidoService pedidoService;
	private final ClienteService clienteService;
	private final ComercialService comercialService;

	public PedidoControlador(PedidoService pedidoService, ClienteService clienteService,
			ComercialService comercialService) {
		this.pedidoService = pedidoService;
		this.clienteService = clienteService;
		this.comercialService = comercialService;
	}

	@GetMapping("/pedidos")
	public String listar(Model model) {
		model.addAttribute("listaPedidos", pedidoService.listAllDetalles());
		return "pedidos";
	}

	@GetMapping("/pedidos/{id}")
	public String detalle(@PathVariable int id, Model model) {
		PedidoDetalle pedido = pedidoService.findDetalle(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
		model.addAttribute("pedido", pedido);
		return "pedido-detalle";
	}

	@GetMapping("/pedidos/crear")
	public String formularioAlta(Model model) {
		prepararFormulario(model, new Pedido(0, BigDecimal.ZERO, null, 0, 0), false);
		return "crear-pedido";
	}

	@PostMapping("/pedidos/crear")
	public String alta(
			@RequestParam BigDecimal total,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
			@RequestParam(required = false) Integer clienteId,
			@RequestParam(required = false) Integer comercialId,
			Model model) {
		Pedido pedido = new Pedido(0, total, fecha, valorOpcionVacia(clienteId), valorOpcionVacia(comercialId));
		if (!relacionesValidas(clienteId, comercialId)) {
			prepararFormulario(model, pedido, false);
			model.addAttribute("errorRelacion", "Selecciona un cliente y un comercial válidos.");
			return "crear-pedido";
		}
		pedidoService.create(pedido);
		return "redirect:/pedidos";
	}

	@GetMapping("/pedidos/editar/{id}")
	public String formularioEdicion(@PathVariable int id, Model model) {
		Pedido pedido = pedidoService.find(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
		prepararFormulario(model, pedido, true);
		return "editar-pedido";
	}

	@PostMapping("/pedidos/editar/{id}")
	public String edicion(
			@PathVariable int id,
			@RequestParam BigDecimal total,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
			@RequestParam(required = false) Integer clienteId,
			@RequestParam(required = false) Integer comercialId,
			Model model) {
		Pedido pedido = new Pedido(id, total, fecha, valorOpcionVacia(clienteId), valorOpcionVacia(comercialId));
		if (!relacionesValidas(clienteId, comercialId)) {
			prepararFormulario(model, pedido, true);
			model.addAttribute("errorRelacion", "Selecciona un cliente y un comercial válidos.");
			return "editar-pedido";
		}
		pedidoService.update(pedido);
		return "redirect:/pedidos";
	}

	@PostMapping("/pedidos/borrar/{id}")
	public String borrado(@PathVariable int id) {
		pedidoService.delete(id);
		return "redirect:/pedidos";
	}

	private void prepararFormulario(Model model, Pedido pedido, boolean modoEdicion) {
		model.addAttribute("pedido", pedido);
		model.addAttribute("modoEdicion", modoEdicion);
		model.addAttribute("listaClientes", clienteService.listAll());
		model.addAttribute("listaComerciales", comercialService.listAll());
		model.addAttribute("accionFormulario", modoEdicion
				? "/pedidos/editar/" + pedido.getId()
				: "/pedidos/crear");
	}

	private boolean relacionesValidas(Integer clienteId, Integer comercialId) {
		if (clienteId == null || comercialId == null) {
			return false;
		}
		List<Cliente> clientes = clienteService.listAll();
		List<Comercial> comerciales = comercialService.listAll();
		return clientes.stream().anyMatch(cliente -> cliente.getId() == clienteId)
				&& comerciales.stream().anyMatch(comercial -> comercial.getId() == comercialId);
	}

	private int valorOpcionVacia(Integer id) {
		return id == null ? 0 : id;
	}
}