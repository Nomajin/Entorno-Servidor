package org.iesvdm.controlador;

import org.springframework.stereotype.Controller;
import org.iesvdm.servicios.ClienteService;
import org.springframework.ui.Model;
import java.util.List;
import org.iesvdm.modelo.Cliente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class ClienteControlador {

    private final ClienteService clienteService;

    public ClienteControlador(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/clientes")
    public String listar(Model model) {

        List<Cliente> listaClientes = clienteService.listAll();
        model.addAttribute("listaClientes", listaClientes);

        return "clientes";
    }

    @PostMapping("/clientes/borrar/{id}")
    public String borrar(@PathVariable int id) {
        clienteService.delete(id);
        return "redirect:/clientes";
    }
    
}
