package org.iesvdm.controlador;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice(annotations = Controller.class)
public class RestriccionIntegridadAdvice {

	@ExceptionHandler(DataIntegrityViolationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public String manejarRestriccionIntegridad(Model model) {
		model.addAttribute("mensajeError",
				"No se puede borrar esta persona porque está asociada a uno o más pedidos. "
						+ "No se eliminó ningún dato.");
		return "error-restriccion";
	}
}