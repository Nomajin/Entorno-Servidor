package org.iesvdm.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class PedidoDAOImpl implements PedidoDAO {

	private static final String PEDIDO_DETALLE_SELECT = """
			SELECT p.id, p.total, p.fecha, p.id_cliente, p.id_comercial,
			       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
			       CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS comercial_nombre
			FROM pedido p
			JOIN cliente c ON p.id_cliente = c.id
			JOIN comercial co ON p.id_comercial = co.id
			""";

	private final JdbcTemplate jdbcTemplate;

	PedidoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public synchronized void create(Pedido pedido) {
		String sqlInsert = """
				INSERT INTO pedido (total, fecha, id_cliente, id_comercial)
				VALUES (?, ?, ?, ?)
				""";

		KeyHolder keyHolder = new GeneratedKeyHolder();
		int rows = jdbcTemplate.update(connection -> {
			PreparedStatement statement = connection.prepareStatement(sqlInsert, new String[] { "id" });
			statement.setBigDecimal(1, pedido.getTotal());
			statement.setObject(2, pedido.getFecha());
			statement.setInt(3, pedido.getClienteId());
			statement.setInt(4, pedido.getComercialId());
			return statement;
		}, keyHolder);

		pedido.setId(keyHolder.getKey().intValue());
		log.info("Insertados {} registros.", rows);
	}

	@Override
	public List<Pedido> getAll() {
		List<Pedido> pedidos = jdbcTemplate.query(
				"SELECT * FROM pedido",
				(rs, rowNum) -> mapPedido(rs));

		log.info("Devueltos {} registros.", pedidos.size());
		return pedidos;
	}

	@Override
	public Optional<Pedido> find(int id) {
		List<Pedido> pedidos = jdbcTemplate.query(
				"SELECT * FROM pedido WHERE id = ?",
				(rs, rowNum) -> mapPedido(rs), id);

		return pedidos.stream().findFirst();
	}

	@Override
	public List<PedidoDetalle> getAllDetalles() {
		return jdbcTemplate.query(PEDIDO_DETALLE_SELECT,
				(rs, rowNum) -> mapPedidoDetalle(rs));
	}

	@Override
	public Optional<PedidoDetalle> findDetalle(int id) {
		List<PedidoDetalle> pedidos = jdbcTemplate.query(
				PEDIDO_DETALLE_SELECT + " WHERE p.id = ?",
				(rs, rowNum) -> mapPedidoDetalle(rs), id);

		return pedidos.stream().findFirst();
	}

	@Override
	public void update(Pedido pedido) {
		int rows = jdbcTemplate.update("""
				UPDATE pedido SET
					total = ?,
					fecha = ?,
					id_cliente = ?,
					id_comercial = ?
				WHERE id = ?
				""", pedido.getTotal(), pedido.getFecha(), pedido.getClienteId(),
				pedido.getComercialId(), pedido.getId());

		log.info("Update de Pedido con {} registros actualizados.", rows);
	}

	@Override
	public void delete(int id) {
		int rows = jdbcTemplate.update("DELETE FROM pedido WHERE id = ?", id);
		log.info("Delete de Pedido con {} registros eliminados.", rows);
	}

	private Pedido mapPedido(ResultSet resultSet) throws SQLException {
		return new Pedido(
				resultSet.getInt("id"),
				resultSet.getBigDecimal("total"),
				resultSet.getObject("fecha", LocalDate.class),
				resultSet.getInt("id_cliente"),
				resultSet.getInt("id_comercial"));
	}

	private PedidoDetalle mapPedidoDetalle(ResultSet resultSet) throws SQLException {
		return new PedidoDetalle(
				resultSet.getInt("id"),
				resultSet.getBigDecimal("total"),
				resultSet.getObject("fecha", LocalDate.class),
				resultSet.getInt("id_cliente"),
				resultSet.getInt("id_comercial"),
				resultSet.getString("cliente_nombre"),
				resultSet.getString("comercial_nombre"));
	}
}