package org.iesvdm.ventas;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.iesvdm.dao.PedidoDAO;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;

@SpringBootTest
class PedidoDAOIntegrationTest {

	@Autowired
	private PedidoDAO pedidoDAO;

	@Test
	void joinedReadsReturnNamesAndPreserveRelationIds() {
		List<PedidoDetalle> detalles = pedidoDAO.getAllDetalles();

		assertFalse(detalles.isEmpty());
		for (PedidoDetalle detalle : detalles) {
			Pedido pedido = pedidoDAO.find(detalle.getId()).orElseThrow();

			assertEquals(pedido.getClienteId(), detalle.getClienteId());
			assertEquals(pedido.getComercialId(), detalle.getComercialId());
			assertNotNull(detalle.getClienteNombre());
			assertNotNull(detalle.getComercialNombre());
			assertFalse(detalle.getClienteNombre().contains("null"));
			assertFalse(detalle.getComercialNombre().contains("null"));
			assertFalse(detalle.getClienteNombre().endsWith(" "));
			assertFalse(detalle.getComercialNombre().endsWith(" "));
			assertEquals(detalle, pedidoDAO.findDetalle(detalle.getId()).orElseThrow());
		}
	}
}