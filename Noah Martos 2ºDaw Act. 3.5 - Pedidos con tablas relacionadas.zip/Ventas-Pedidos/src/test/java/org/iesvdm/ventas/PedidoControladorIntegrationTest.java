package org.iesvdm.ventas;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.matchesPattern;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.iesvdm.dao.ClienteDAO;
import org.iesvdm.dao.ComercialDAO;
import org.iesvdm.modelo.Cliente;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.iesvdm.servicios.ClienteService;
import org.iesvdm.servicios.ComercialService;
import org.iesvdm.servicios.PedidoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class PedidoControladorIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ClienteService clienteService;

	@Autowired
	private ComercialService comercialService;

	@Autowired
	private PedidoService pedidoService;

	@Autowired
	private ClienteDAO clienteDAO;

	@Autowired
	private ComercialDAO comercialDAO;

	@Test
	void createFormRendersWithRelationIdFields() throws Exception {
		mockMvc.perform(get("/pedidos/crear"))
				.andExpect(status().isOk())
				.andExpect(view().name("crear-pedido"))
				.andExpect(content().string(containsString("<select id=\"clienteId\" name=\"clienteId\"")))
				.andExpect(content().string(containsString("<select id=\"comercialId\" name=\"comercialId\"")));
	}

	@Test
	void editFormSelectsCurrentRelationIds() throws Exception {
		Pedido pedido = pedidoService.listAll().get(0);

		mockMvc.perform(get("/pedidos/editar/{id}", pedido.getId()))
				.andExpect(status().isOk())
				.andExpect(view().name("editar-pedido"))
				.andExpect(content().string(matchesPattern("(?s).*<option value=\"" + pedido.getClienteId()
						+ "\"\\s+selected=\"selected\">.*")))
				.andExpect(content().string(matchesPattern("(?s).*<option value=\"" + pedido.getComercialId()
						+ "\"\\s+selected=\"selected\">.*")));
	}

	@Test
	void createRejectsUnknownClientOrCommercial() throws Exception {
		int validClientId = clienteService.listAll().get(0).getId();
		int validCommercialId = comercialService.listAll().get(0).getId();

		mockMvc.perform(post("/pedidos/crear")
				.param("total", "25.50")
				.param("clienteId", "2147483647")
				.param("comercialId", String.valueOf(validCommercialId)))
				.andExpect(status().isOk())
				.andExpect(view().name("crear-pedido"))
				.andExpect(content().string(containsString("Selecciona un cliente y un comercial válidos.")));

		mockMvc.perform(post("/pedidos/crear")
				.param("total", "25.50")
				.param("clienteId", String.valueOf(validClientId))
				.param("comercialId", "2147483647"))
				.andExpect(status().isOk())
				.andExpect(view().name("crear-pedido"))
				.andExpect(content().string(containsString("Selecciona un cliente y un comercial válidos.")));

		Pedido pedidoExistente = pedidoService.listAll().get(0);
		mockMvc.perform(post("/pedidos/editar/{id}", pedidoExistente.getId())
				.param("total", "25.50")
				.param("clienteId", String.valueOf(validClientId))
				.param("comercialId", "2147483647"))
				.andExpect(status().isOk())
				.andExpect(view().name("editar-pedido"))
				.andExpect(content().string(containsString("Selecciona un cliente y un comercial válidos.")));

		Pedido pedidoSinCambios = pedidoService.find(pedidoExistente.getId()).orElseThrow();
		org.junit.jupiter.api.Assertions.assertEquals(pedidoExistente.getTotal(), pedidoSinCambios.getTotal());
		org.junit.jupiter.api.Assertions.assertEquals(pedidoExistente.getClienteId(), pedidoSinCambios.getClienteId());
		org.junit.jupiter.api.Assertions.assertEquals(pedidoExistente.getComercialId(), pedidoSinCambios.getComercialId());
	}

	@Test
	void createAndEditPersistBothSelectedRelations() throws Exception {
		List<Cliente> clientes = clienteService.listAll();
		List<Comercial> comerciales = comercialService.listAll();
		Cliente clienteInicial = clientes.get(0);
		Cliente clienteEditado = clientes.get(1);
		Comercial comercialInicial = comerciales.get(0);
		Comercial comercialEditado = comerciales.get(1);
		BigDecimal totalInicial = new BigDecimal("67321.45");
		int pedidoId = 0;

		try {
			mockMvc.perform(post("/pedidos/crear")
					.param("total", totalInicial.toPlainString())
					.param("fecha", "2026-10-25")
					.param("clienteId", String.valueOf(clienteInicial.getId()))
					.param("comercialId", String.valueOf(comercialInicial.getId())))
					.andExpect(status().is3xxRedirection());

			Pedido creado = buscarPedido(totalInicial, clienteInicial.getId(), comercialInicial.getId());
			pedidoId = creado.getId();
			org.junit.jupiter.api.Assertions.assertEquals(LocalDate.of(2026, 10, 25), creado.getFecha());

			mockMvc.perform(post("/pedidos/editar/{id}", pedidoId)
					.param("total", "67322.55")
					.param("fecha", "2026-10-26")
					.param("clienteId", String.valueOf(clienteEditado.getId()))
					.param("comercialId", String.valueOf(comercialEditado.getId())))
					.andExpect(status().is3xxRedirection());

			Pedido editado = pedidoService.find(pedidoId).orElseThrow();
			org.junit.jupiter.api.Assertions.assertEquals(0, new BigDecimal("67322.55").compareTo(editado.getTotal()));
			org.junit.jupiter.api.Assertions.assertEquals(LocalDate.of(2026, 10, 26), editado.getFecha());
			org.junit.jupiter.api.Assertions.assertEquals(clienteEditado.getId(), editado.getClienteId());
			org.junit.jupiter.api.Assertions.assertEquals(comercialEditado.getId(), editado.getComercialId());
		} finally {
			if (pedidoId != 0) {
				pedidoService.delete(pedidoId);
			}
		}
	}

	@Test
	void listAndDetailShowRelatedFullNames() throws Exception {
		PedidoDetalle detalle = pedidoService.listAllDetalles().get(0);

		mockMvc.perform(get("/pedidos"))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString(detalle.getClienteNombre())))
				.andExpect(content().string(containsString(detalle.getComercialNombre())));

		mockMvc.perform(get("/pedidos/{id}", detalle.getId()))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString(detalle.getClienteNombre())))
				.andExpect(content().string(containsString(detalle.getComercialNombre())));
	}

	@Test
	void nullSecondSurnamesRenderAsCleanFullNamesInListAndDetail() throws Exception {
		Cliente cliente = new Cliente(0, "Cliente", "Apellido", null, "Ciudad", null);
		Comercial comercial = new Comercial(0, "Comercial", "Apellido", null, 0.1f);
		clienteDAO.create(cliente);
		comercialDAO.create(comercial);
		Pedido pedido = new Pedido(0, new BigDecimal("123456.78"), LocalDate.of(2026, 10, 20),
				cliente.getId(), comercial.getId());

		try {
			pedidoService.create(pedido);
			String nombreCliente = "Cliente Apellido";
			String nombreComercial = "Comercial Apellido";

			mockMvc.perform(get("/pedidos"))
					.andExpect(status().isOk())
					.andExpect(content().string(containsString(nombreCliente)))
					.andExpect(content().string(containsString(nombreComercial)))
					.andExpect(content().string(org.hamcrest.Matchers.not(containsString("null"))));

			mockMvc.perform(get("/pedidos/{id}", pedido.getId()))
					.andExpect(status().isOk())
					.andExpect(content().string(containsString(nombreCliente)))
					.andExpect(content().string(containsString(nombreComercial)))
					.andExpect(content().string(org.hamcrest.Matchers.not(containsString("null"))));
		} finally {
			pedidoService.delete(pedido.getId());
			clienteDAO.delete(cliente.getId());
			comercialDAO.delete(comercial.getId());
		}
	}

	@Test
	void personDeletesWithRelatedOrdersReturnClearConflictWithoutCascade() throws Exception {
		Cliente cliente = new Cliente(0, "Cliente", "Con Pedido", null, "Ciudad", null);
		Comercial comercial = new Comercial(0, "Comercial", "Con Pedido", null, 0.1f);
		clienteDAO.create(cliente);
		comercialDAO.create(comercial);
		Pedido pedido = new Pedido(0, new BigDecimal("98765.43"), LocalDate.of(2026, 10, 21),
				cliente.getId(), comercial.getId());

		try {
			pedidoService.create(pedido);

			mockMvc.perform(post("/clientes/borrar/{id}", cliente.getId()))
					.andExpect(status().isConflict())
					.andExpect(view().name("error-restriccion"))
					.andExpect(content().string(containsString("está asociada a uno o más pedidos")))
					.andExpect(content().string(containsString("No se eliminó ningún dato")));

			mockMvc.perform(post("/comerciales/borrar/{id}", comercial.getId()))
					.andExpect(status().isConflict())
					.andExpect(view().name("error-restriccion"))
					.andExpect(content().string(containsString("está asociada a uno o más pedidos")))
					.andExpect(content().string(containsString("No se eliminó ningún dato")));

			org.junit.jupiter.api.Assertions.assertTrue(pedidoService.find(pedido.getId()).isPresent());
			org.junit.jupiter.api.Assertions.assertTrue(clienteService.listAll().stream()
					.anyMatch(actual -> actual.getId() == cliente.getId()));
			org.junit.jupiter.api.Assertions.assertTrue(comercialService.listAll().stream()
					.anyMatch(actual -> actual.getId() == comercial.getId()));
		} finally {
			pedidoService.delete(pedido.getId());
			clienteDAO.delete(cliente.getId());
			comercialDAO.delete(comercial.getId());
		}
	}

	private Pedido buscarPedido(BigDecimal total, int clienteId, int comercialId) {
		return pedidoService.listAll().stream()
				.filter(pedido -> pedido.getTotal().compareTo(total) == 0
						&& pedido.getClienteId() == clienteId
						&& pedido.getComercialId() == comercialId)
				.findFirst()
				.orElseThrow();
	}
}